﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Final.Models
{
    public class MultipleTablesJoinData
    {
        public string Table1Col1 { get; set; }
        public string Table2Col1 { get; set; }

        public string Table3Col1 { get; set; }
    }
}
